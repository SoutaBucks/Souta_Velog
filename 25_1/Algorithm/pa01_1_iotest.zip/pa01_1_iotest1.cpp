
#include <iostream>
#include <vector>

using namespace std;

int N, K;
vector<int> vector1;

int insertion_sort() {
  int i, j, key, answer = 0;

  if(K == 1)
    return 0;

  for (i = 1; i < N; i++) {
    key = vector1[i];

    j = i -1;
     while(j >= 0 && vector1[j] > key) {
      if(i == K - 1)
        answer++;
      vector1[j + 1] = vector1[j];
      j--;
    }
    vector1[j + 1] = key;
    if(j >= 0 && i == K - 1)
      answer++;
  }
  return answer;
}

int main() {
  cin >> N >> K;
  int n;
  for (int i = 0; i < N; i++) {
    cin >> n;
    vector1.push_back(n);
  }

  cout << insertion_sort() << endl;
}