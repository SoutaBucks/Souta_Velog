
#include <iostream>
#include <utility>
#include <sstream>
#include <vector>


using namespace std;

pair<int, int> start;
pair<int, int> to;

int main() {
  string inputString;
  getline(cin, inputString);

  stringstream ss(inputString);

  vector<string> strings;

  string word;

  while (ss >> word)
    strings.push_back(word);

  to.first = stoi(strings[0].substr(1, 3));
  to.second = stoi(strings[0].substr(4, 6));

  start.first = stoi(strings[1].substr(1, 3));
  start.second = stoi(strings[1].substr(4, 6));

  int startTime = start.first * 60 + start.second;
  int toTime = to.first * 60 + to.second;

  for(int i = 2; i < strings.size(); i++) {
    string temp;
    if(i == 2)
      temp = strings[i].substr(1, strings[i].size() - 2);
    else
      temp = strings[i].substr(0, strings[i].size() - 1);

    if(temp == "next")
      startTime += 10;
    else
      startTime -= 10;

    if(startTime > toTime)
      startTime = toTime;
    else if(startTime < 0)
      startTime = 0;
  }

  start.first = startTime / 60;
  start.second = startTime % 60;
  cout << "[";
  if(start.first < 10)
    cout << "0" << start.first;
  else
    cout << start.first;
  cout << ":";
  if(start.second < 10)
    cout << "0" << start.second;
  else
    cout << start.second;
  cout << "]";
}